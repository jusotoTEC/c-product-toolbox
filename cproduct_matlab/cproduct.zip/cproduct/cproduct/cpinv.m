function X=cpinv(A)

    %       Description: Computes the tensor pseudoinverse using the reduced c-product
    %   Syntax Function: X = cpinv(A)
    %            Inputs: A = tensor of dimension  m x n x p
    %            Output: X = tensor of dimension  n x m x p
    %
    %        References: C-product toolbox                    
    %                    https://github.com/jusotoTEC/c-product-toolbox
    %
    %   Code written by: Pablo Soto-Quiros (jusoto@tec.ac.cr) and
    %                    Samuel Valverde-Sanchez (savalverde@itcr.ac.cr)
    
    [m,n,p]=size(A); 
        
    At = dct(A, [], 3);
    Xt = zeros(n, m, p);
    for j = 1:p
        Xt(:, :, j) = pinv(At(:, :, j));  
    end
    X = idct(Xt, [], 3);    
    
end